package Assignment.java;

public class constructor1 {
  int a,b;
  public constructor1() {
	  a=10;
	  b=20;
  }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		constructor1 c=new constructor1();
		System.out.println(c.a*c.b);

	}

}
