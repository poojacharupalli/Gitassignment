package Assignment.java;
import java.util.TreeSet;
import java.util.Scanner;

public class treeSet {

	public static void main(String[] args) {
		TreeSet<String> t=new TreeSet();
		t.add("hyd");
		t.add("bang");
		t.add("delhi");
		t.contains("java");
		System.out.println(t);
		

	}

}
